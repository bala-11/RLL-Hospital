export class AdminLogin {
    constructor(public emailid:string,
    public password:string){}
    
}

export class RetrieveDoctor {
    constructor(public did:number,
        public address:string,
        public dage:number,
        public dgender:string,
        public dname:string,
        
        public dstatus:string,
        public emailid:string,
        public phno:string,
        public specialization:string
        ){}
}

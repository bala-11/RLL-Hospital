import { RetrieveDoctor } from './retrieve-doctor';

describe('RetrieveDoctor', () => {
  it('should create an instance', () => {
    expect(new RetrieveDoctor()).toBeTruthy();
  });
});

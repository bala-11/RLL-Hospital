export class Patient {
    constructor(public pid:number,
        public dpid:number,
        public pname:string,
        public emailid:string,
        public paddress:string,
        public pgender:string,
        public page:number,
        public pstatus:string,
        public symptoms:string,
        public mobile:number,
        // public date:number
        ){}
}
